#!/bin/bash

export GEMINI_API_KEY="AIzaSyB5pTP8bfEWEE9RaowcPx8_d3HyWVsKQ4Y"
export PORT=3000

node career-interpreter/server.js
