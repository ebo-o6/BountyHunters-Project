@echo off

set GEMINI_API_KEY=AIzaSyB5pTP8bfEWEE9RaowcPx8_d3HyWVsKQ4Y

node career-interpreter/server.js

pause
